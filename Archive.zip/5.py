from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.webdriver import ActionChains
from selenium.webdriver.common.keys import Keys
import time
from Driver import *
from Logger import *

driver = install_driver()
try:
    link = "https://ru.aliexpress.com"
    query = "glasses"
    driver.get(link)

    searchFiled = driver.find_element_by_id('search-key')
    searchFiled.send_keys(query)
    searchFiled.send_keys(Keys.RETURN)

except Exception as ex:
    logException("AliExpress Test", __file__, ex)
    driver.quit()

